/**
 * 队伍状态
 */
export const teamStatusEnum = {
    0: '公开',
    1: '私有',
    2: '加密',
}