import {UserType} from "./user";

/**
 * 队伍类型
 */
export type TeamType = {
    id: number;
    name: string;
    description: string;
    expireTime?: Date;//表示可有可无
    maxNum: number;
    password?: string,
    // todo 定义枚举值类型，更规范
    status: number;
    createTime: string;
    updateTime: string;
    createUser?: UserType;
    hasJoinNum?: number;
    hasJoin?: boolean;
    teamUrl?: string;
};