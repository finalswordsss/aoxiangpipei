<template>
  <form action="/">
    <van-search
        v-model="searchText"
        show-action
        placeholder="请输入搜索关键词"
        @search="onSearch"
        @cancel="onCancel"
    />
  </form>

  <van-divider content-position="left">已选标签</van-divider>
  <div v-if="activeIds.length === 0">请选择标签</div>
  <van-row gutter="16" style="padding: 0 16px">
    <van-col v-for="tag in activeIds">
      <van-tag closeable size="small" type="primary" @close="doClose(tag)">
        {{tag}}
      </van-tag>
    </van-col>
  </van-row>

  <van-divider content-position="left">选择标签</van-divider>
  <van-tree-select
      v-model:active-id="activeIds"
      v-model:main-active-index="activeIndex"
      :items="tagList"
  />
  <div style="padding: 16px">
    <van-button type="primary" block @click="doSearchResult">搜索</van-button>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { showToast } from 'vant';
import {useRouter} from "vue-router";

const searchText = ref('');

const router = useRouter();

//所有标签
const originTagList = [{
  text: '性别',
  children: [
    { text: '男', id: '男' },
    { text: '女', id: '女' },
  ],
},
  {
    text: '学历',
    children: [
      { text: '大一', id: '大一' },
      { text: '大二', id: '大二' },
      { text: '大三', id: '大三' },
      { text: '大四', id: '大四' },
      { text: '研究生', id: '研究生' },
      { text: '博士', id: '博士' },
      { text: '求职中', id: '求职中' },
      { text: '打工人', id: '打工人' },
    ],
  },
  {
    text: '前端',
    children: [
      { text: '前端', id: '前端' },
      { text: 'HTML', id: 'HTML' },
      { text: 'CSS', id: 'CSS' },
      { text: 'JavaScript', id: 'JavaScript' },
      { text: 'Vue', id: 'Vue' },
      { text: 'React', id: 'React' },
      { text: 'NodeJS', id: 'NodeJS' },
    ],
  },
  {
    text: '后端',
    children: [
      { text: '后端', id: '后端' },
      { text: 'Java', id: 'Java' },
      { text: 'C++', id: 'C++' },
      { text: 'C#', id: 'C#' },
      { text: 'Android', id: 'Android' },
      { text: 'Go', id: 'Go' },
      { text: 'PHP', id: 'PHP' },
      { text: 'Linux', id: 'Linux' },
    ],
  },
  {
    text: '数据库操作',
    children: [
      { text: '数据库', id: '数据库' },
      { text: 'SQL', id: 'SQL' },
      { text: 'MySQL', id: 'MySQL' },
      { text: 'MongDB', id: 'MongDB' },
      { text: 'Oracle', id: 'Oracle' },
    ],
  },
  {
    text: '人工智能',
    children: [
      { text: '人工智能', id: '人工智能' },
      { text: 'Python', id: 'Python' },
    ],
  },
  {
    text: '工具',
    children: [
      { text: 'Git', id: 'Git' },
      { text: 'Gitee', id: 'Gitee' },
      { text: 'GitHub', id: 'GitHub' },
      { text: 'GitLab', id: 'GitLab' },
    ],
  },
  {
    text: '其他',
    children: [
      { text: '算法', id: '算法' },
      { text: '信息安全', id: '信息安全' },
      { text: '测试', id: '测试' },
      { text: '运维', id: '运维' },
      { text: '大数据', id: '大数据' },
      { text: '操作系统', id: '操作系统' },
    ],
  },
];

//标签列表
let tagList = ref(originTagList);

/**
 * 搜索过滤
 * @param val
 */
const onSearch = (val) => {
  tagList.value = originTagList.map(parentTag => {
    const tempChildren = [...parentTag.children];
    const tempParentTag = {...parentTag};
    tempParentTag.children = tempChildren.filter(item => item.text.includes(searchText.value));
    return tempParentTag;
  });
}

const onCancel = () => {
  searchText.value = '';
  tagList.value = originTagList;
};

//左侧索引
const activeIndex = ref(0);
//右侧索引，已选中的标签
const activeIds = ref([]);

//移除标签
const doClose = (tag) => {
  activeIds.value = activeIds.value.filter(item => {
    return item !== tag;
  })
}

/**
 * 执行搜索
 */
const doSearchResult = () => {
  router.push({
    path: '/user/list',
    query: {
      tags: activeIds.value
    }
  })
}

</script>

<style scoped>

</style>
