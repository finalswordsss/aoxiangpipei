<template>
  <template v-if="user">
    <van-cell-group inset>
      <van-divider/>
      <van-cell title="昵称" is-link to="/user/edit" :value="user.username"
                @click="toEdit('username', '昵称', user.username)" />
      <van-divider/>
      <van-cell title="账号" :value="user.userAccount" />
      <van-divider/>
      <van-cell title="头像" is-link to="/user/picPage">
        <img style="height: 48px" :src="user.avatarUrl" />
      </van-cell>
      <van-divider/>
      <van-cell title="性别" is-link to="/user/edit" :value="user.gender === 0? '男' : '女'"
                @click="toEdit('gender', '性别',  user.gender === 0? '男' : '女')" />
      <van-divider/>
      <van-cell title="电话" is-link to="/user/edit" :value="user.phone"
                @click="toEdit('phone', '电话',  user.phone)" />
      <van-divider/>
      <van-cell title="邮箱" is-link to="/user/edit" :value="user.email"
                @click="toEdit('email', '邮箱',  user.email)"/>
      <van-divider/>
      <van-cell title="个人介绍" is-link to="/user/edit" :value="user.profile"
                @click="toEdit('profile', '个人介绍',  user.profile)"/>
      <van-divider/>
      <van-cell title="编号" :value="user.id" />
      <van-divider/>
      <van-cell title="修改标签" is-link to="/user/updateTags" @click="toEdit('tags', '标签', user.tags)" />
      <van-divider/>
      <van-cell title="注册时间" :value="dateFormat(user.createTime)" />
      <van-divider/>
    </van-cell-group>
  </template>
</template>

<script setup lang="ts">
import { useRouter } from "vue-router";
import {onMounted, ref} from "vue";
import {getCurrentUser} from "../services/user";
import dateFormat from "../plugins/dateFormat.ts";
import {showFailToast, showSuccessToast} from "vant";

  // const user = {
  //   id: 1,
  //   username: '大大怪',
  //   userAccount: 'Alonso',
  //   avatarUrl: 'https://636f-codenav-8grj8px727565176-1256524210.tcb.qcloud.la/img/logo.png',
  //   gender: '男',
  //   phone: '12345',
  //   email: '123@qq.com',
  //   planetCode: '123',
  //   createTime: new Date(),
  // }

  const user = ref();
  const router = useRouter();

  onMounted(async () => {
    user.value = await getCurrentUser();
    // onMounted(async ()=>{
    //   const res = await myAxios.get('/user/current');
    //   if (res.code === 0){
    //     user.value =res.data;
    //     showSuccessToast('获取用户信息成功');
    //   }else {
    //     showFailToast('获取用户信息成功');
    //   }
    // })
  })

  // const fileUpload = ref([])

  // console.log(fileUpload.value)

/**
 *
 * @param editKey
 * @param editName 字段
 * @param currentValue 值
 */
  const toEdit = (editKey: string, editName: string, currentValue: string) => {
    //如果 editKey是 tags，就跳转到修改标签页
    if (editKey === 'tags'){
      if (currentValue == null){
        currentValue = '';
      }
      router.push({
        path: '/user/updateTags',
        query: {
          currentValue,
        }
      })
    }else {
      router.push({
        path: '/user/edit',
        query: {
          editKey,
          currentValue,
          editName
        }
      })
    }
  }

</script>

<style scoped>

</style>