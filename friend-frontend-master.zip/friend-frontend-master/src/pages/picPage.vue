<template>
    <van-uploader v-model="fileList"
                  :after-read="onAfterRead"
                  accept="image/png, image/jpeg"
                  multiple :max-count="1"
                  :max-size="500 * 1024"
    />
    <div style="margin: 16px;">
    </div>
</template>

<script setup lang="ts">
import {useRouter} from "vue-router";
import {ref} from "vue";
import myAxios from "../plugins/myAxios";
import {showFailToast, showSuccessToast} from "vant";
import {getCurrentUser} from "../services/user";

const router =useRouter();

const fileList = ref([]);

const onAfterRead = async (file) =>{
  const formData = new FormData();
  formData.append('file', file.file);
  console.log("file= " + file);
  const currentUser = await getCurrentUser();
  // currentUserId.value = currentUser.id;
  // avatarUrl.value = file.content;
  const res = myAxios.post('/user/updateImg', {
    "id": currentUser.id,
    "file": formData.get("file")
  }, {
    headers:  {
      "content-type": "multipart/form-data",
    },
  })
      .then(function (response){
        console.log("/user/update success= " + response);
        showSuccessToast('图片上传成功');
        router.replace("/user");
      })
      .catch(function (error) {
        console.log('/user/update error', error);
        showFailToast('请求失败');
      })
  if (res.code == 0){
    showSuccessToast("图片成功");
  }else {
    // showFailToast("图片失败");
  }
}



</script>

<style scoped>

</style>