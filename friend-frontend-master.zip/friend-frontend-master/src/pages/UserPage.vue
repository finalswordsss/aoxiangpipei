<!--<template>-->
<!--  <template v-if="user">-->
<!--    <van-form @submit="onSubmit">-->
<!--      <van-cell title="当前用户" :value="user?.username" />-->
<!--      <van-cell title="修改信息" is-link to="/user/update" />-->
<!--      <van-cell title="我创建的队伍" is-link to="/user/team/create" />-->
<!--      <van-cell title="我加入的队伍" is-link to="/user/team/join" />-->
<!--      <div style="margin: 16px;">-->
<!--        <van-button round block type="primary" native-type="submit">-->
<!--          注销-->
<!--        </van-button>-->
<!--      </div>-->
<!--    </van-form>-->
<!--  </template>-->
<!--</template>-->
<template>
  <template v-if="user">
    <van-cell-group inset>
      <van-cell to="/user/update">
        <van-card
            :desc="user.profile"
            :thumb="user.avatarUrl"
            :title="user?.username"
        >
          <template #tags>
            <van-tag plain type="primary" v-for="tag in user.tags" style="margin: 5px">
              {{tag}}
            </van-tag>
          </template>
        </van-card>
      </van-cell>
      <van-divider/>

      <van-cell :value="user.id" center title="编号">
        <template #icon>
          <van-icon name="manager-o" size="18"/>
        </template>
      </van-cell>
      <van-divider/>
      <van-cell center is-link title="我创建的队伍" to="/user/team/create">
        <template #icon>
          <van-icon name="cluster-o" size="18"/>
        </template>
      </van-cell>
      <van-divider/>
      <van-cell center is-link title="我加入的队伍" to="/user/team/join">
        <template #icon>
          <van-icon name="friends-o" size="18"/>
        </template>
      </van-cell>
      <van-divider/>

      <template v-if="currentUser?.userRole === 1">
        <van-cell  center is-link title="查看私有队伍" to="/user/team/private">
          <template #icon >
            <van-icon name="closed-eye" size="18"/>
          </template>
        </van-cell>
        <van-divider/>
      </template>


      <van-cell :value="dateFormat(user.createTime)" center title="注册时间">
        <template #icon>
          <van-icon name="clock-o" size="18"/>
        </template>
      </van-cell>
      <van-divider/>
      <van-cell center title="退出登录" @click="quit">
        <template #icon>
          <van-icon name="close" size="18"/>
        </template>
      </van-cell>
    </van-cell-group>
  </template>
</template>

<script setup lang="ts">
  import { useRouter } from "vue-router";
  import {onMounted, ref} from "vue";
  import {getCurrentUser} from "../services/user";
  import myAxios from "../plugins/myAxios";
  import {showFailToast, showSuccessToast} from "vant";
  import dateFormat from "../plugins/dateFormat.ts";

  // const user = {
  //   id: 1,
  //   username: '大大怪',
  //   userAccount: 'Alonso',
  //   avatarUrl: 'https://636f-codenav-8grj8px727565176-1256524210.tcb.qcloud.la/img/logo.png',
  //   gender: '男',
  //   phone: '12345',
  //   email: '123@qq.com',
  //   planetCode: '123',
  //   createTime: new Date(),
  // }

  const user = ref();
  const router = useRouter();

  onMounted(async () => {
    user.value = await getCurrentUser();
    if (user.value.tags) {
      user.value.tags = JSON.parse(user.value.tags);
    }
    // onMounted(async ()=>{
    //   const res = await myAxios.get('/user/current');
    //   if (res.code === 0){
    //     user.value =res.data;
    //     showSuccessToast('获取用户信息成功');
    //   }else {
    //     showFailToast('获取用户信息成功');
    //   }
    // })
  })

  const currentUser = ref();
  //调用获取当前用户方法
  onMounted(async () => {
    currentUser.value = await getCurrentUser();
  })

  /**
   * 用户注销
   */
  const quit = async () => {
    const res = await myAxios.post("/user/logout");
    if (res.code == 0){
      showSuccessToast("注销成功");
      router.push("/");
    }else {
      showFailToast("注销失败");
    }
  }

  const toEdit = (editKey: string, editName: string, currentValue: string) => {
    router.push({
      path: '/user/edit',
      query: {
        editKey,
        currentValue,
        editName
      }
    })
  }

</script>

<style scoped>
/*:root {*/
/*  --van-card-font-size: 10px;*/
/*}*/
</style>