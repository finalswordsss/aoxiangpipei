package com.friend.test;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.friend.model.domain.User;
import com.friend.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest
public class testDatabase {

    @Resource
    private UserService userService;

    @Test
    public void test(){
        String username = "jack";
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.eq("username", username);
        List<User> userList = userService.list(userQueryWrapper);
        System.out.println("===============");
        userList.forEach(System.out::println);
    }
}
