package com.friend.service;

import com.friend.model.domain.User;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import javax.annotation.Resource;

@SpringBootTest
public class RedisTest {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    @Test
    public void redisTest(){
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
        User user = new User();
        user.setId(1L);
        user.setUsername("jack");
        //增
        valueOperations.set("jack", "杰克");
        valueOperations.set("tom", 1);
        valueOperations.set("lucy", 2.0);
        valueOperations.set("jams", user);
        //查
        Object userTest = valueOperations.get("jack");
        Assertions.assertTrue(((String)userTest).equals("杰克"));
        userTest = valueOperations.get("tom");
        Assertions.assertTrue(1 == (Integer)userTest);
        userTest = valueOperations.get("lucy");
        Assertions.assertTrue(2.0 == (Double) userTest);
        System.out.println(valueOperations.get("jams"));

    }
}
