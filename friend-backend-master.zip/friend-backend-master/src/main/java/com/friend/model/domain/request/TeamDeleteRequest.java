package com.friend.model.domain.request;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户删除队伍请求体
 *
 * @author Alonso
 */
@Data
public class TeamDeleteRequest implements Serializable{

    private static final long serialVersionUID = -4162304142710323660L;

    /**
     * 队伍id
     */
    private Long teamId;
}
