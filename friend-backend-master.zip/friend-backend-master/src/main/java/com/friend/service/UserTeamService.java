package com.friend.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.friend.model.domain.UserTeam;

/**
* @author Alonso
* @description 针对表【user_team(用户队伍关系表)】的数据库操作Service
* @createDate 2023-02-02 14:05:17
*/
public interface UserTeamService extends IService<UserTeam> {

}
