package com.friend.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.friend.model.domain.Team;
import com.friend.model.domain.User;
import com.friend.model.domain.request.TeamDeleteRequest;
import com.friend.model.domain.request.TeamJoinRequest;
import com.friend.model.domain.request.TeamQuitRequest;
import com.friend.model.domain.request.TeamUpdateRequest;
import com.friend.model.dto.TeamQuery;
import com.friend.model.vo.TeamUserVO;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
* @author Alonso
* @description 针对表【team(队伍表)】的数据库操作Service
* @createDate 2023-02-02 14:02:57
*/
public interface TeamService extends IService<Team> {

    /**
     * 创建队伍
     *
     * @param team
     * @param loginUser
     * @return
     */
    long addTeam(Team team, User loginUser);

    /**
     * 查询队伍
     *
     * @param teamQuery
     * @return
     */
    List<TeamUserVO> listTeams(TeamQuery teamQuery, boolean isAdmin);

    /**
     * 查询我创建的队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    List<TeamUserVO> listMyCreateTeams(TeamQuery teamQuery, boolean isAdmin);

    /**
     * 查询我加入的队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    List<TeamUserVO> listMyJoinTeams(TeamQuery teamQuery, boolean isAdmin);

    /**
     * 查询私有队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    List<TeamUserVO> listPrivateTeams(TeamQuery teamQuery, boolean isAdmin);

    /**
     * 修改队伍信息
     *
     * @param teamUpdateRequest
     * @param loginUser
     * @return
     */
    boolean updateTeam(TeamUpdateRequest teamUpdateRequest, User loginUser);

    /**
     * 修改队伍头像
     *
     * @param file
     * @param teamId
     * @return
     */
    int updateTeamUrl(MultipartFile file, Long teamId);

    /**
     * 加入队伍
     *
     * @param teamJoinRequest
     * @param loginUser
     * @return
     */
    boolean joinTeam(TeamJoinRequest teamJoinRequest, User loginUser);

    /**
     * 退出队伍
     *
     * @param teamQuitRequest
     * @param loginUser
     * @return
     */
    boolean quitTeam(TeamQuitRequest teamQuitRequest, User loginUser);

    /**
     * 删除队伍
     *
     * @param teamDeleteRequest
     * @param loginUser
     * @return
     */
    boolean deleteTeam(TeamDeleteRequest teamDeleteRequest, User loginUser);

    /**
     * 根据队伍id 获取所有加入队伍的用户信息
     *
     * @param id
     * @return
     */
    List<User> listJoinUsers(Long id);
}
