package com.friend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.friend.model.domain.request.UserRegisterRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.friend.common.ErrorCode;
import com.friend.contant.UserConstant;
import com.friend.exception.BusinessException;
import com.friend.mapper.UserMapper;
import com.friend.model.domain.User;
import com.friend.service.UserService;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicSessionCredentials;
import com.qcloud.cos.model.PutObjectRequest;
import com.qcloud.cos.region.Region;
import com.utils.AlgorithmUtils;
import com.utils.TencentCOSUtils;
import javafx.util.Pair;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 用户服务实现类
 *
 * @author Alonso
 */
@Service
@Slf4j
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
        implements UserService {

    @Resource
    private UserMapper userMapper;

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 盐值，混淆密码
     */
    private static final String SALT = "abcd";

    /**
     * 用户注册
     *
     * @param userRegisterRequest
     * @return
     */
    @Override
    public long userRegister(UserRegisterRequest userRegisterRequest) {
        //从请求信息中获取用户注册信息
        String userAccount = userRegisterRequest.getUserAccount();
        String userPassword = userRegisterRequest.getUserPassword();
        String checkPassword = userRegisterRequest.getCheckPassword();
        Integer gender = userRegisterRequest.getGender();
        String phone = userRegisterRequest.getPhone();
        String email = userRegisterRequest.getEmail();
        // 1. 校验
        if (StringUtils.isAnyBlank(userAccount, userPassword, checkPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (userAccount.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户名过短");
        }
        if (userPassword.length() < 8 || checkPassword.length() < 8) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码过短");
        }
        // 账户不能包含特殊字符
        String validPattern = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPattern).matcher(userAccount);
        if (matcher.find()) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账户不能包含特殊字符");
        }
        // 密码和校验密码相同
        if (!userPassword.equals(checkPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "确认密码与密码不同");
        }
        // 账户不能重复
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userAccount", userAccount);
        long count = userMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号重复");
        }
        // 2. 加密
        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());
        // 3. 插入数据
        User user = new User();
        user.setUserAccount(userAccount);
        user.setUsername(userAccount);
        user.setUserPassword(encryptPassword);
        user.setGender(gender);
        user.setPhone(phone);
        user.setEmail(email);
        user.setProfile("这个人很懒，介绍都不写。");
        user.setTags("[]");
        //首次注册的用户有默认头像
        user.setAvatarUrl("https://llong7-1314997135.cos.ap-guangzhou.myqcloud.com/image/userImg/defaultImg.jpg");
        boolean saveResult = this.save(user);
        System.out.println("user= " + user);
        if (!saveResult) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "注册失败");
        }
        return user.getId();
    }

    /**
     * 用户登录
     *
     * @param userAccount  用户账户
     * @param userPassword 用户密码
     * @param request
     * @return
     */
    @Override
    public User userLogin(String userAccount, String userPassword, HttpServletRequest request) {
        // 1. 校验
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            return null;
        }
        if (userAccount.length() < 4) {
            return null;
        }
        if (userPassword.length() < 8) {
            return null;
        }
        // 账户不能包含特殊字符
        String validPattern = "[`~!@#$%^&*()+=|{}':;',\\\\[\\\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
        Matcher matcher = Pattern.compile(validPattern).matcher(userAccount);
        if (matcher.find()) {
            return null;
        }
        // 2. 加密
        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());
        // 查询用户是否存在
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userAccount", userAccount);
        queryWrapper.eq("userPassword", encryptPassword);
        User user = userMapper.selectOne(queryWrapper);
        // 用户不存在
        if (user == null) {
            log.info("user login failed, userAccount cannot match userPassword");
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户不存在!");
        }
        // 3. 用户脱敏
        User safetyUser = getSafetyUser(user);
        // 4. 记录用户的登录态
        request.getSession().setAttribute(UserConstant.USER_LOGIN_STATE, safetyUser);
        return safetyUser;
    }

    /**
     * 用户脱敏
     *
     * @param originUser
     * @return
     */
    @Override
    public User getSafetyUser(User originUser) {
        if (originUser == null) {
            return null;
        }
        User safetyUser = new User();
        safetyUser.setId(originUser.getId());
        safetyUser.setUsername(originUser.getUsername());
        safetyUser.setUserAccount(originUser.getUserAccount());
        safetyUser.setProfile(originUser.getProfile());
        safetyUser.setAvatarUrl(originUser.getAvatarUrl());
        safetyUser.setGender(originUser.getGender());
        safetyUser.setPhone(originUser.getPhone());
        safetyUser.setEmail(originUser.getEmail());
        safetyUser.setUserRole(originUser.getUserRole());
        safetyUser.setUserStatus(originUser.getUserStatus());
        safetyUser.setCreateTime(originUser.getCreateTime());
        safetyUser.setTags(originUser.getTags());
        return safetyUser;
    }

    /**
     * 用户注销
     *
     * @param request
     */
    @Override
    public int userLogout(HttpServletRequest request) {
        // 移除登录态
        request.getSession().removeAttribute(UserConstant.USER_LOGIN_STATE);
        return 1;
    }

    /**
     * 根据标签搜索用户(内存过滤)
     *
     * @param tagNameList 用户要拥有的标签
     * @return
     */
    @Override
    public List<User> searchUsersByTags(List<String> tagNameList) {
        if (CollectionUtils.isEmpty(tagNameList)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //1.先查询所有用户
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        List<User> userList = userMapper.selectList(queryWrapper);
        Gson gson = new Gson();
        //2.在内存中判断是否包含要求的标签
        return userList.stream().filter(user -> {
            String tagsStr = user.getTags();
            if (StringUtils.isBlank(tagsStr)) {
                return false;
            }
            Set<String> tempTagNameSet = gson.fromJson(tagsStr, new TypeToken<Set<String>>() {
            }.getType());
            //判断为空的情况
            tempTagNameSet = Optional.ofNullable(tempTagNameSet).orElse(new HashSet<>());
            for (String tagName : tagNameList) {
                if (!tempTagNameSet.contains(tagName)) {
                    return false;
                }
            }
            return true;
        }).map(this::getSafetyUser).collect(Collectors.toList());
    }

    /**
     * 获取当前用户登录态
     *
     * @param request
     * @return
     */
    @Override
    public User getCurrentUserLogin(HttpServletRequest request) {
        //判断请求
        if (request == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User userObj = (User) request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        //获取到登录态后再判断
        if (userObj == null) {
            //未登录
            throw new BusinessException(ErrorCode.NOT_LOGIN);
        }
        Long userId = userObj.getId();
        User user = this.baseMapper.selectById(userId);
        return user;
    }

    /**
     * 读缓存
     * @param redisKey
     * @return
     */
    @Override
    public Page<User> getRecommendUserByRedis(String redisKey) {
        //如果有缓存，直接读缓存
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
        //设置储存缓存（friend:user:recommend:id）
        Page<User> userPage = (Page<User>) valueOperations.get(redisKey);
        return userPage;
    }

    /**
     * 写缓存
     * @return
     */
    @Override
    public void setRecommendUserByRedis(String redisKey, Page<User> userPage) {
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
        //设置过期时间 1秒
        valueOperations.set(redisKey, userPage, 1000, TimeUnit.MILLISECONDS);
    }

    /**
     * 修改用户信息
     *
     * @param user
     * @param loginUser
     * @return
     */
    @Override
    public int updateUser(User user, User loginUser) {
        //更新用户信息，先获取到用户的 id，判断 id < 0 就没有此用户
        Long userId = user.getId();
        if (userId < 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //校验权限（需要获取到用户登录态）
        //1.管理员可以更新任意信息
        //2.用户只能更新自己的信息

        //当前用户态的用户（已登录）不是管理员，并且修改的用户信息也不是已登录用户的（修改的不是自己的），就抛异常
        if (!isAdmin(loginUser) && !Objects.equals(userId, loginUser.getId())) {
            throw new BusinessException(ErrorCode.NO_AUTH);
        }
        User oldUser = this.getById(user.getId());
        //修改的用户不存在
        if (oldUser == null) {
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //触发更新
        return this.baseMapper.updateById(user);
    }

    /**
     * 修改用户头像
     *
     * @param user
     * @param loginUser
     * @param file
     * @return
     */
    @Override
    public int updateImg(User user, User loginUser, MultipartFile file) {
        //更新用户信息，先获取到用户的 id，判断 id < 0 就没有此用户
        Long userId = user.getId();
        if (userId < 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //校验权限（需要获取到用户登录态）
        //1.管理员可以更新任意信息
        //2.用户只能更新自己的信息

        //当前用户态的用户（已登录）不是管理员，并且修改的用户信息也不是已登录用户的（修改的不是自己的），就抛异常
        if (!isAdmin(loginUser) && !Objects.equals(userId, loginUser.getId())) {
            throw new BusinessException(ErrorCode.NO_AUTH);
        }
        User oldUser = this.getById(user.getId());
        //修改的用户不存在
        if (oldUser == null) {
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //n=0,图片存入用户图片的地址
        int n = 0;
        //上传图片并拿到对象地址
        String newAvatarUrl = TencentCOSUtils.uploadFile(file, n);
        //对象地址就是图片地址
        user.setAvatarUrl(newAvatarUrl);

        //触发更新
        return this.baseMapper.updateById(user);
    }

    /**
     * 修改用户标签
     *
     * @param userId
     * @param loginUser
     * @param tags
     * @return
     */
    @Override
    public int updateTags(Long userId, User loginUser, List<String> tags) {
        //更新用户信息，先获取到用户的 id，判断 id < 0 就没有此用户
        if (userId < 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //将拿到的标签列表转换成 Json格式
        Gson gson = new Gson();
        String StrToJson = gson.toJson(tags);
        //拿到要修改的用户id，然后修改
        //当前用户态的用户（已登录）不是管理员，并且修改的用户信息也不是已登录用户的（修改的不是自己的），就抛异常
        if (!isAdmin(loginUser) && !Objects.equals(userId, loginUser.getId())) {
            throw new BusinessException(ErrorCode.NO_AUTH);
        }
        User user = new User();
        user.setId(userId);
        user.setTags(StrToJson);
        //触发更新
        return this.baseMapper.updateById(user);
    }

    /**
     * 是否为管理员
     *
     * @param request
     * @return
     */
    @Override
    public boolean isAdmin(HttpServletRequest request) {
        if (request == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User loginUser = (User) request.getSession().getAttribute(UserConstant.USER_LOGIN_STATE);
        //如果 登录态不为空，并且权限 userRole == ADMIN_ROLE，就是管理员
        return loginUser != null && loginUser.getUserRole() == UserConstant.ADMIN_ROLE;
    }

    /**
     * 是否为管理员
     *
     * @param loginUser
     * @return
     */
    @Override
    public boolean isAdmin(User loginUser) {
        // 仅管理员可查询
        //如果 登录态不为空，并且权限 userRole == ADMIN_ROLE，就是管理员
        return loginUser != null && loginUser.getUserRole() == UserConstant.ADMIN_ROLE;
    }

    /**
     * 匹配用户
     *
     * @param pageNum
     * @param pageSize
     * @param loginUser
     * @return
     */
    @Override
    public List<User> matchUsers(long pageSize, long pageNum, User loginUser) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("id", "tags");
        queryWrapper.isNotNull("tags");
        List<User> userList = this.list(queryWrapper);
//        Page<User> userPage = new Page<>(pageNum, pageSize);
//        Page<User> page = this.page(userPage, queryWrapper);
//        List<User> userList = page.getRecords();
        String tags = loginUser.getTags();
        Gson gson = new Gson();
        List<String> tagList = gson.fromJson(tags, new TypeToken<List<String>>() {
        }.getType());
        // 用户列表的下标 => 相似度
        List<Pair<User, Long>> list = new ArrayList<>();
        // 依次计算所有用户和当前用户的相似度
        for (int i = 0; i < userList.size(); i++) {
            User user = userList.get(i);
            String userTags = user.getTags();
            // 无标签或者为当前用户自己
            // == 运算符不能排除掉自己和无标签的用户，用 equals
            if (StringUtils.isBlank(userTags) || user.getId().equals(loginUser.getId())) {
                continue;
            }
                List<String> userTagList = gson.fromJson(userTags, new TypeToken<List<String>>() {
            }.getType());
            // 计算分数
            long distance = AlgorithmUtils.minDistance(tagList, userTagList);
            list.add(new Pair<>(user, distance));
        }
        // 按编辑距离由小到大排序
        //topUserPairList 排序完的所有数据
        List<Pair<User, Long>> topUserPairList = list.stream()
                .sorted((a, b) -> (int) (a.getValue() - b.getValue()))
                //.limit(pageSize)//10
                .collect(Collectors.toList());
        // 原本顺序的 userId 列表
        List<Long> userIdList = topUserPairList.stream().map(pair -> pair.getKey().getId()).collect(Collectors.toList());
        //将拿到的全部数据进行分页
        int startIndex = (int)((pageNum - 1) * pageSize);
        int endIndex = (int)(pageNum * pageSize);
        List<Long> subList = userIdList.subList(startIndex, endIndex);
        QueryWrapper<User> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.in("id", subList);
        // 1, 3, 2
        // User1、User2、User3
        // 1 => User1, 2 => User2, 3 => User3
//        Map<Long, List<User>> userIdUserListMap = this.list(userQueryWrapper)
//                .stream()
//                .map(user -> getSafetyUser(user))
//                .collect(Collectors.groupingBy(User::getId));

        //上面进行了分页，这里拿到分页的用户id，直接从数据库中查对应的
        Map<Long, List<User>> userIdUserListMap = this.list(userQueryWrapper)
                .stream()
                .map(user -> getSafetyUser(user))
                .collect(Collectors.groupingBy(User::getId));
        List<User> finalUserList = new ArrayList<>();
        for (Long userId : subList) {
            finalUserList.add(userIdUserListMap.get(userId).get(0));
        }
//        System.out.println("========================");
//        finalUserList.forEach(System.out::println);
        return finalUserList;
    }

    /**
     * 根据标签搜索用户(SQL 查询版)
     *
     * @param tagNameList 用户要拥有的标签
     * @return
     */
    @Deprecated //表示方法过时
    private List<User> searchUsersByTagsBySQL(List<String> tagNameList) {
        if (CollectionUtils.isEmpty(tagNameList)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        userMapper.selectCount(null);
        //拼接 and 查询
        //like '%Java%' and like '%C++%'
        for (String tagName : tagNameList) {
            queryWrapper = queryWrapper.like("tags", tagName);
        }
        List<User> userList = userMapper.selectList(queryWrapper);
        return userList.stream().map(this::getSafetyUser).collect(Collectors.toList());
    }

//    @Override
//    public boolean UploadPictures(User user, User loginUser){
//        //更新用户信息，先获取到用户的 id，判断 id < 0 就没有此用户
//        Long userId = user.getId();
//        if (userId < 0) {
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
//        }
//        //校验权限（需要获取到用户登录态）
//        //1.管理员可以更新任意信息
//        //2.用户只能更新自己的信息
//
//        //当前用户态的用户（已登录）不是管理员，并且修改的用户信息也不是已登录用户的（修改的不是自己的），就抛异常
//        if (!isAdmin(loginUser) && !Objects.equals(userId, loginUser.getId())) {
//            throw new BusinessException(ErrorCode.NO_AUTH);
//        }
//        User oldUser = this.getById(user.getId());
//        //修改的用户不存在
//        if (oldUser == null) {
//            throw new BusinessException(ErrorCode.NULL_ERROR);
//        }
//        //触发更新
//        return this.baseMapper.updateById(user);
//    }
}




