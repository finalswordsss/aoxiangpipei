package com.friend.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.friend.model.domain.User;
import com.friend.model.domain.request.UserRegisterRequest;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 用户服务
 *
 * @author Alonso
 */
public interface UserService extends IService<User> {

    /**
     * 用户注册
     *
     * @param userRegisterRequest
     * @return 新用户 id
     */
    long userRegister(UserRegisterRequest userRegisterRequest);

    /**
     * 用户登录
     *
     * @param userAccount  用户账户
     * @param userPassword 用户密码
     * @param request
     * @return 脱敏后的用户信息
     */
    User userLogin(String userAccount, String userPassword, HttpServletRequest request);

    /**
     * 用户脱敏
     *
     * @param originUser
     * @return
     */
    User getSafetyUser(User originUser);

    /**
     * 用户注销
     *
     * @param request
     * @return
     */
    int userLogout(HttpServletRequest request);

    /**
     * 根据标签搜索用户
     *
     * @param tagNameList
     * @return
     */
    List<User> searchUsersByTags(List<String> tagNameList);

    /**
     * 获取当前用户登录态
     *
     * @param request
     * @return
     */
    User getCurrentUserLogin(HttpServletRequest request);

    /**
     * 读缓存
     *
     * @param redisKey
     * @return
     */
    Page<User> getRecommendUserByRedis(String redisKey);

    /**
     * 写缓存
     *
     * @param redisKey
     * @param userPage
     */
    void setRecommendUserByRedis(String redisKey, Page<User> userPage);

    /**
     * 修改用户信息
     *
     * @param user
     * @param loginUser
     * @return
     */
    int updateUser(User user, User loginUser);

    /**
     * 修改用户头像
     *
     * @param user
     * @param loginUser
     * @param file
     * @return
     */
    int updateImg(User user, User loginUser, MultipartFile file);

    /**
     * 修改用户标签
     *
     * @param userId
     * @param loginUser
     * @param tags
     * @return
     */
    int updateTags(Long userId, User loginUser, List<String> tags);

    /**
     * 是否为管理员
     *
     * @param request
     * @return
     */
    boolean isAdmin(HttpServletRequest request);

    /**
     * 是否为管理员
     *
     * @param loginUser
     * @return
     */
    boolean isAdmin(User loginUser);

    /**
     * 匹配用户
     *
     * @param pageNum
     * @param pageSize
     * @param loginUser
     * @return
     */
    List<User> matchUsers(long pageSize, long pageNum, User loginUser);
}
