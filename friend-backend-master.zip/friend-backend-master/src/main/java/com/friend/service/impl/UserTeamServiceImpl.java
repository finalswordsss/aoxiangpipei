package com.friend.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.friend.mapper.UserTeamMapper;
import com.friend.model.domain.UserTeam;
import com.friend.service.UserTeamService;
import org.springframework.stereotype.Service;

/**
* @author Alonso
* @description 针对表【user_team(用户队伍关系表)】的数据库操作Service实现
* @createDate 2023-02-02 14:05:17
*/
@Service
public class UserTeamServiceImpl extends ServiceImpl<UserTeamMapper, UserTeam>
    implements UserTeamService{

}




