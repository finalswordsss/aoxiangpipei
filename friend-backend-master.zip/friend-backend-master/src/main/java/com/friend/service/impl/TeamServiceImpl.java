package com.friend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.friend.common.ErrorCode;
import com.friend.exception.BusinessException;
import com.friend.mapper.TeamMapper;
import com.friend.model.domain.Team;
import com.friend.model.domain.User;
import com.friend.model.domain.UserTeam;
import com.friend.model.domain.request.TeamDeleteRequest;
import com.friend.model.domain.request.TeamJoinRequest;
import com.friend.model.domain.request.TeamQuitRequest;
import com.friend.model.domain.request.TeamUpdateRequest;
import com.friend.model.dto.TeamQuery;
import com.friend.model.enums.TeamStatusEnum;
import com.friend.model.vo.TeamUserVO;
import com.friend.model.vo.UserVO;
import com.friend.service.TeamService;
import com.friend.service.UserService;
import com.friend.service.UserTeamService;
import com.google.gson.Gson;
import com.utils.TencentCOSUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.friend.job.PreCacheJob.PRODUCT_NAME;

/**
* @author Alonso
* @description 针对表【team(队伍表)】的数据库操作Service实现
* @createDate 2023-02-02 14:02:57
*/
@Service
public class TeamServiceImpl extends ServiceImpl<TeamMapper, Team>
    implements TeamService{

    @Resource
    private UserTeamService userTeamService;

    @Resource
    private UserService userService;

    @Resource
    private RedissonClient redissonClient;

    /**
     * 创建队伍
     *
     * @param team
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public long addTeam(Team team, User loginUser){

        //1. 请求参数是否为空？（队伍的信息，用户登录态）
        if (team == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //2. 是否登录，未登录不允许创建
        if (loginUser == null){
            throw new BusinessException(ErrorCode.NOT_LOGIN);
        }
        //3. 校验信息
        //   1. 队伍人数 > 1 且 <= 20
        int maxNum = Optional.ofNullable(team.getMaxNum()).orElse(0);//如果为空，直接赋值0
        if (maxNum < 1 || maxNum >= 20){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍人数不满足要求");
        }
        //   2. 队伍名称 <= 20
        String name = team.getName();
        if (StringUtils.isBlank(name) || name.length() > 20){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍名称过长");
        }
        //   3. 描述 <= 512
        String description = team.getDescription();
        if (StringUtils.isBlank(description) || description.length() > 512){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍描述过长");
        }
        //   4. status 是否公开（int）不传默认为 0（公开）
        Integer status = Optional.ofNullable(team.getStatus()).orElse(0);
        //当前队伍状态
        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
        if (statusEnum == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍状态不满足要求");
        }
        //   5. 如果 status 是加密状态，一定要有密码，且密码 <= 32
        String password = team.getPassword();
        if (TeamStatusEnum.SECRET.equals(statusEnum)){
            if (StringUtils.isBlank(password) || password.length() > 32){
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "密码设置不正确");
            }
        }
        //   6. 超时时间 > 当前时间
        Date expireTime = team.getExpireTime();
        if (new Date().after(expireTime)){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "超时时间 > 当前时间");
        }
        //   7. 校验用户最多创建 5 个队伍
        final long userId = loginUser.getId();
        QueryWrapper<Team> queryWrapper = new QueryWrapper<>();
        //判断 team 表中 userId字段与 userId 相匹配的个数
        queryWrapper.eq("userId", userId);
        long count = this.count(queryWrapper);
        if (count >= 5){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户最多创建5个队伍");
        }
        //4. 插入队伍信息到队伍表
        //代码走到这里，说明 team 表中就剩 id和 userId没传参了，执行下面操作
        team.setId(null);//表中会自增
        team.setUserId(userId);
        //首次创建队伍有默认头像
        team.setTeamUrl("https://llong7-1314997135.cos.ap-guangzhou.myqcloud.com/image/teamImg/friends.jpg");
        //执行 teamService的 添加方法
        boolean result = this.save(team);
        //验证事务
//        if (true){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "插入用户关系表失败");
//        }
        if (!result || team == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "创建队伍失败");
        }
        //5. 插入用户  => 队伍关系到关系表
        //队伍添加成功到 team 表后，就可以在关系表添加用户
        UserTeam userTeam = new UserTeam();
        //UserId、TeamId、JoinTime 需要从 team中获取
        userTeam.setUserId(userId);
        Long teamId = team.getId();
        userTeam.setTeamId(teamId);
        userTeam.setJoinTime(new Date());
        result = userTeamService.save(userTeam);
        if (!result){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "创建队伍失败");
        }
        return teamId;
    }

    /**
     * 查询队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<TeamUserVO> listTeams(TeamQuery teamQuery, boolean isAdmin) {
        QueryWrapper<Team> queryWrapper = new QueryWrapper<>();
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //查询id
        Long id = teamQuery.getId();
        if (id != null && id > 0){
            queryWrapper.eq("id", id);
        }
        //查询 idList
        List<Long> idList = teamQuery.getIdList();
        if (CollectionUtils.isNotEmpty(idList)){
            queryWrapper.in("id", idList);
        }
        //查询队伍名称
        String name = teamQuery.getName();
        if (StringUtils.isNotBlank(name)){
            queryWrapper.like("name", name);
        }
        //查询队伍描述
        String description = teamQuery.getDescription();
        if (StringUtils.isNotBlank(description)){
            queryWrapper.like("description", description);
        }
        //查询的关键字
        String searchText = teamQuery.getSearchText();
        //关键字查询就是模糊查询队伍名称和描述
        if (StringUtils.isNotBlank(searchText)){
            queryWrapper.and(qw -> qw.like("name", searchText)
                    .or().like("description", searchText));
        }
        //最大人数相等
        Integer maxNum = teamQuery.getMaxNum();
        if (maxNum != null && maxNum > 0){
            queryWrapper.eq("maxNum", maxNum);
        }
        //查询创建人
        Long userId = teamQuery.getUserId();
        if (userId != null && userId > 0){
            queryWrapper.eq("userId", userId);
        }
        //查询队伍状态
//        Integer status = teamQuery.getStatus();
//        //获取队伍当前状态
//        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
//        //如果没填写队伍状态，默认设置为公开
//        if (statusEnum == null){
//            statusEnum = TeamStatusEnum.PUBLIC;
//        }
//        //如果队伍状态是加密的，并且也不是管理员
//        if (TeamStatusEnum.PRIVATE.equals(statusEnum) && !isAdmin){
//            throw new BusinessException(ErrorCode.NO_AUTH);
//        }
//        queryWrapper.eq("status", statusEnum.getValue());

        //显示没过期的队伍
        //expireTime 大于 当前时间或者为空（没设过期时间表示永久），说明没过期
        queryWrapper.and(qw -> qw.gt("expireTime", new Date())
                .or().isNull("expireTime"));

        //查询到所有队伍
        List<Team> teamList = this.list(queryWrapper);
        //查询完 list为空，直接返回 空list
        if (CollectionUtils.isEmpty(teamList)){
            return new ArrayList<>();
        }

        List<TeamUserVO> teamUserVOList = new ArrayList<>();
        for (Team team : teamList) {
            //每个队伍的id
            Long teamId = team.getId();
            //再查询关系表，获取每个队伍的加入人数
            QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamId);
            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);

            //继续关联查询创建人的信息
            //获取每个队伍的创建人id
            userId = team.getUserId();
            if (userId == null){
                //id为空，就接着获取下一个队伍
                continue;
            }
            //根据 id，查询 user表对应用户
            User user = userService.getById(userId);
            TeamUserVO teamUserVO = new TeamUserVO();
            BeanUtils.copyProperties(team, teamUserVO);
            //用户脱敏
            if (user != null){
                UserVO userVO = new UserVO();
                BeanUtils.copyProperties(user, userVO);
                teamUserVO.setCreateUser(userVO);
                teamUserVO.setHasJoinNum((int)hasJoinNum);
                //将队伍加入状态改为 true
                teamUserVO.setHasJoin(true);
            }
            //把封装好的队伍信息放入要求返回的 list中
            teamUserVOList.add(teamUserVO);
        }
        return teamUserVOList;
    }

    /**
     * 查询我创建的队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<TeamUserVO> listMyCreateTeams(TeamQuery teamQuery, boolean isAdmin) {
        //先查询队伍表
        QueryWrapper<Team> queryWrapper = new QueryWrapper<>();
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //查询id
        Long id = teamQuery.getId();
        if (id != null && id > 0){
            queryWrapper.eq("id", id);
        }
        //查询 idList
        List<Long> idList = teamQuery.getIdList();
        if (CollectionUtils.isNotEmpty(idList)){
            queryWrapper.in("id", idList);
        }
        //查询队伍名称
        String name = teamQuery.getName();
        if (StringUtils.isNotBlank(name)){
            queryWrapper.like("name", name);
        }
        //查询队伍描述
        String description = teamQuery.getDescription();
        if (StringUtils.isNotBlank(description)){
            queryWrapper.like("description", description);
        }
        //查询的关键字
        String searchText = teamQuery.getSearchText();
        //关键字查询就是模糊查询队伍名称和描述
        if (StringUtils.isNotBlank(searchText)){
            queryWrapper.and(qw -> qw.like("name", searchText)
                    .or().like("description", searchText));
        }
        //最大人数相等
        Integer maxNum = teamQuery.getMaxNum();
        if (maxNum != null && maxNum > 0){
            queryWrapper.eq("maxNum", maxNum);
        }
        //查询创建人
        Long userId = teamQuery.getUserId();
        if (userId != null && userId > 0){
            queryWrapper.eq("userId", userId);
        }
        //查询队伍状态
//        Integer status = teamQuery.getStatus();
        //获取队伍当前状态
//        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
        //如果没填写队伍状态，默认设置为公开
//        if (statusEnum == null){
//            statusEnum = TeamStatusEnum.PUBLIC;
//        }
        //如果队伍状态是加密的，并且也不是管理员
//        if (TeamStatusEnum.PRIVATE.equals(statusEnum) && !isAdmin){
//            throw new BusinessException(ErrorCode.NO_AUTH);
//        }
        //queryWrapper.eq("status", statusEnum.getValue());
        queryWrapper.and(qw -> qw.eq("status", 0)
                .or().eq("status", 1)
                .or().eq("status", 2));

        //显示没过期的队伍
        //expireTime 大于 当前时间或者为空（没设过期时间表示永久），说明没过期
        queryWrapper.and(qw -> qw.gt("expireTime", new Date())
                .or().isNull("expireTime"));

        //拿到我创建的所有队伍信息
        List<Team> teamList = this.list(queryWrapper);
        //查询完 list为空，直接返回 空list
        if (CollectionUtils.isEmpty(teamList)){
            return new ArrayList<>();
        }
        List<TeamUserVO> teamUserVOList = new ArrayList<>();
        for (Team team : teamList) {
            //获取每个队伍的id
            Long teamId = team.getId();
            //再查询关系表，获取每个队伍的加入人数
            QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamId);
            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);
            //继续关联查询创建人的信息
            //获取每个队伍的创建人id
            userId = team.getUserId();
            if (userId == null){
                //id为空，就接着获取下一个队伍
                continue;
            }
            //根据 id，查询 user表对应用户
            User user = userService.getById(userId);
            TeamUserVO teamUserVO = new TeamUserVO();
            BeanUtils.copyProperties(team, teamUserVO);
            //用户脱敏
            if (user != null){
                UserVO userVO = new UserVO();
                BeanUtils.copyProperties(user, userVO);
                teamUserVO.setCreateUser(userVO);
                teamUserVO.setHasJoinNum((int)hasJoinNum);
                //将队伍加入状态改为 true
                teamUserVO.setHasJoin(true);
            }
            //把封装好的队伍信息放入要求返回的 list中
            teamUserVOList.add(teamUserVO);
        }
        return teamUserVOList;
    }

    /**
     * 查询我加入的队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<TeamUserVO> listMyJoinTeams(TeamQuery teamQuery, boolean isAdmin) {
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        Long userId = teamQuery.getUserId();
        List<Long> idList = teamQuery.getIdList();
        List<TeamUserVO> teamUserVOList = new ArrayList<>();

        //先查询关系表
        QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
        userTeamQueryWrapper.eq("userId", userId);
        userTeamQueryWrapper.in("teamId", idList);
        List<UserTeam> userTeamList = userTeamService.list(userTeamQueryWrapper);
        if (CollectionUtils.isEmpty(userTeamList)){
            return new ArrayList<>();
        }

        for (UserTeam userTeam : userTeamList) {
            Long teamId = userTeam.getTeamId();
            userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamId);
            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);
            QueryWrapper<Team> queryWrapper = new QueryWrapper<>();
            //查询队伍id
            if (teamId != null && teamId > 0){
                queryWrapper.eq("id", teamId);
            }
            //查询 idList
//            List<Long> idList = teamQuery.getIdList();
//            if (CollectionUtils.isNotEmpty(idList)){
//                queryWrapper.in("id", idList);
//            }
            //查询队伍名称
            String name = teamQuery.getName();
            if (StringUtils.isNotBlank(name)){
                queryWrapper.like("name", name);
            }
            //查询队伍描述
            String description = teamQuery.getDescription();
            if (StringUtils.isNotBlank(description)){
                queryWrapper.like("description", description);
            }
            //查询的关键字
            String searchText = teamQuery.getSearchText();
            //关键字查询就是模糊查询队伍名称和描述
            if (StringUtils.isNotBlank(searchText)){
                queryWrapper.and(qw -> qw.like("name", searchText)
                        .or().like("description", searchText));
            }
            //最大人数相等
            Integer maxNum = teamQuery.getMaxNum();
            if (maxNum != null && maxNum > 0){
                queryWrapper.eq("maxNum", maxNum);
            }
            //查询创建人
//            userId = teamQuery.getUserId();
//            if (userId != null && userId > 0){
//                queryWrapper.eq("userId", userId);
//            }
            //查询队伍状态
//        Integer status = teamQuery.getStatus();
            //获取队伍当前状态
//        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
            //如果没填写队伍状态，默认设置为公开
//        if (statusEnum == null){
//            statusEnum = TeamStatusEnum.PUBLIC;
//        }
            //如果队伍状态是加密的，并且也不是管理员
//        if (TeamStatusEnum.PRIVATE.equals(statusEnum) && !isAdmin){
//            throw new BusinessException(ErrorCode.NO_AUTH);
//        }
            //queryWrapper.eq("status", statusEnum.getValue());
            queryWrapper.and(qw -> qw.eq("status", 0)
                    .or().eq("status", 1)
                    .or().eq("status", 2));

            //显示没过期的队伍
            //expireTime 大于 当前时间或者为空（没设过期时间表示永久），说明没过期
            queryWrapper.and(qw -> qw.gt("expireTime", new Date())
                    .or().isNull("expireTime"));


            List<Team> teamList = this.list(queryWrapper);
            //查询完 list为空，直接返回 空list
            if (CollectionUtils.isEmpty(teamList)){
                return new ArrayList<>();
            }


            //继续关联查询创建人的信息
            for (Team team : teamList) {
                //获取每个队伍的创建人id
                userId = team.getUserId();
                if (userId == null){
                    //id为空，就接着获取下一个队伍
                    continue;
                }
                //根据 id，查询 user表对应用户
                User user = userService.getById(userId);
                TeamUserVO teamUserVO = new TeamUserVO();
                BeanUtils.copyProperties(team, teamUserVO);
                //用户脱敏
                if (user != null){
                    UserVO userVO = new UserVO();
                    BeanUtils.copyProperties(user, userVO);
                    teamUserVO.setCreateUser(userVO);
                    teamUserVO.setHasJoinNum((int)hasJoinNum);
                    //将队伍加入状态改为 true
                    teamUserVO.setHasJoin(true);
                }
                //把封装好的队伍信息放入要求返回的 list中
                teamUserVOList.add(teamUserVO);
            }
        }

        return teamUserVOList;
    }

    /**
     * 查询私有队伍
     *
     * @param teamQuery
     * @param isAdmin
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<TeamUserVO> listPrivateTeams(TeamQuery teamQuery, boolean isAdmin) {
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        QueryWrapper<Team> queryWrapper = new QueryWrapper<>();
        //status=1就是私有队伍
        queryWrapper.eq("status", 1);
        List<Team> teamList = this.list(queryWrapper);
        ArrayList<TeamUserVO> teamUserVOS = new ArrayList<>();
        for (Team team : teamList) {
            Long teamId = team.getId();
            TeamUserVO teamUserVO = new TeamUserVO();
            BeanUtils.copyProperties(team, teamUserVO);
            //查关联表，获取加入队伍的人数
            QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamId);
            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);
            teamUserVO.setHasJoinNum((int) hasJoinNum);
            teamUserVOS.add(teamUserVO);
        }
        return teamUserVOS;
    }

    /**
     * 修改队伍信息
     *
     * @param teamUpdateRequest
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateTeam(TeamUpdateRequest teamUpdateRequest, User loginUser) {
        //判断请求参数
        if (teamUpdateRequest == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //判断队伍是否存在
        Long userId = teamUpdateRequest.getId();
        if (userId == null || userId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Team oldTeam = this.getById(userId);
        if (oldTeam == null){
            throw new BusinessException(ErrorCode.NULL_ERROR, "队伍不存在");
        }
        //判断只有队伍创建者和管理员才能修改队伍信息
            if (!oldTeam.getUserId().equals(loginUser.getId())&& !userService.isAdmin(loginUser)){
            throw new BusinessException(ErrorCode.NO_AUTH);
        }
        //修改队伍状态为加密的话，必须要添加密码
        Integer status = teamUpdateRequest.getStatus();
        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
        if (TeamStatusEnum.SECRET.equals(statusEnum)){
            if (StringUtils.isBlank(teamUpdateRequest.getPassword())){
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "加密队伍必须设置密码");
            }
        }
        Team updateTeam = new Team();
        BeanUtils.copyProperties(teamUpdateRequest, updateTeam);
        //修改队伍信息
        return this.updateById(updateTeam);
    }

    /**
     * 修改队伍头像
     *
     * @param file
     * @param teamId
     * @return
     */
    @Override
    public int updateTeamUrl(MultipartFile file, Long teamId) {
        //n=1,图片存入队伍图片的地址
        int n = 1;
        //上传图片并拿到对象地址
        String teamUrl = TencentCOSUtils.uploadFile(file, n);
        //对象地址就是图片地址
        Team team = new Team();
        team.setId(teamId);
        team.setTeamUrl(teamUrl);
        //触发更新
        return this.baseMapper.updateById(team);
    }

    /**
     * 加入队伍
     *
     * @param teamJoinRequest
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean joinTeam(TeamJoinRequest teamJoinRequest, User loginUser) {
        //判断请求参数
        if (teamJoinRequest == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //判断要加入的队伍 id
        Long teamId = teamJoinRequest.getTeamId();
        if (teamId == null || teamId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //查找该队伍
//        Team joinTeam = this.getById(teamId);
//        if (joinTeam == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR, "加入的队伍不存在");
//        }
        Team joinTeam = getTeamByTeamId(teamId);
        //判断队伍是否过期
        Date expireTime = joinTeam.getExpireTime();
        //1.expireTime.before(new Date())：过期时间在当前时间的前面：已过期
        //2.new Date().after(expireTime)：当前时间在过期时间的后面：已过期
        if (expireTime != null && new Date().after(expireTime)){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍已过期");
        }
        //判断队伍状态
        Integer status = joinTeam.getStatus();
        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
        //私有不得加入
        if (TeamStatusEnum.PRIVATE.equals(statusEnum)){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "禁止加入私有队伍");
        }
        //加密队伍需要密码
        String password = teamJoinRequest.getPassword();
        if (TeamStatusEnum.SECRET.equals(statusEnum)){
            if (StringUtils.isBlank(password) || !password.equals(joinTeam.getPassword())){
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "密码错误");
            }
        }

        Long userId = loginUser.getId();
        //加锁，只有一个线程能获取到锁
        RLock lock = redissonClient.getLock(PRODUCT_NAME + ":friend:join_team");
        try {
            //抢到锁，并执行
            while (true){
                if (lock.tryLock(0, -1, TimeUnit.MILLISECONDS)){
                    System.out.println("getLock: "+Thread.currentThread().getId());
                    //先通过上面的校验，再通过数据库查询，可以减少数据库查询次数
                    //不能重复加入队伍
                    QueryWrapper<UserTeam> queryWrapper = new QueryWrapper<>();
                    //如果 user_team 表中 userId 和 teamId 同时有该用户信息，则已加入
                    queryWrapper.eq("userId", userId);
                    queryWrapper.eq("teamId", teamId);
                    long hasUserJoinTeam = userTeamService.count(queryWrapper);
                    if (hasUserJoinTeam > 0){
                        throw new BusinessException(ErrorCode.PARAMS_ERROR, "该队伍已加入");
                    }

                    //判断该用户加入的队伍是否达到上限
                    queryWrapper = new QueryWrapper<>();
                    queryWrapper.eq("userId", userId);
                    long count = userTeamService.count(queryWrapper);
                    if (count >= 5){
                        throw new BusinessException(ErrorCode.PARAMS_ERROR, "最多加入5个队伍");
                    }

                    //查询要加入的队伍人数是否已满
//        queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("teamId", teamId);
//        long hasTeamJoinNum = userTeamService.count(queryWrapper);
                    long hasTeamJoinNum = this.getTeamNumsByTeamId(teamId);
                    if (hasTeamJoinNum >= joinTeam.getMaxNum()){
                        throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍人数已满");
                    }

                    //加入队伍
                    UserTeam userTeam = new UserTeam();
                    userTeam.setUserId(userId);
                    userTeam.setTeamId(teamId);
                    userTeam.setJoinTime(new Date());
                    return userTeamService.save(userTeam);
                }
            }
        } catch (InterruptedException e) {
            log.error("doCacheReCommendUser error", e);
            return false;
        }finally {
            //注意释放锁要写在 finally 中（写在 try 中，如果前面发生异常就不会执行释放锁）
            //只能释放自己的锁
            if (lock.isHeldByCurrentThread()){
                System.out.println("unlock:" + Thread.currentThread().getId());
                lock.unlock();
            }
        }
    }

    /**
     * 退出队伍
     *
     * @param teamQuitRequest
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean quitTeam(TeamQuitRequest teamQuitRequest, User loginUser) {
        //1. 校验请求参数
        if (teamQuitRequest == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //2. 校验队伍是否存在
        Long teamId = teamQuitRequest.getTeamId();
        if (teamId == null || teamId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        Team team = getTeamByTeamId(teamId);
        //3. 校验我是否已加入队伍
        Long userId = loginUser.getId();
        QueryWrapper<UserTeam> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userId", userId);
        queryWrapper.eq("teamId", teamId);
        UserTeam userTeam = userTeamService.getOne(queryWrapper);
        if (userTeam == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "未加入该队伍");
        }
        //4. 如果队伍
        //   1. 只剩一人，队伍解散
        //获取队伍人数
        long teamNum = getTeamNumsByTeamId(teamId);
        if (teamNum == 1){
            //删除队伍表信息
            this.removeById(teamId);
        }else {
            //   2. 还有其他人
            //      1. 如果是队长退出队伍，权限转移给第二早加入的用户 —— 先来后到只用取 id 最小的 2 条数据

            //队长退出队伍情况
            //两个 id 类型都是引用数据类型Long，所以 == 判断的是地址值是否相等，显然不相等，所以是 false
            //只有基本数据类型才用 == 判断，引用数据类型是用 equals 判断相等
            if (team.getUserId().equals(userId)){
                //如果是队长退出队伍，就查询队伍中所有人，升序
                QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
                userTeamQueryWrapper.eq("teamId", teamId);
                //limit 子句用于限制查询结果返回的数量，常用于分页查询
                userTeamQueryWrapper.last("order by id asc limit 2");
                List<UserTeam> userTeamList = userTeamService.list(userTeamQueryWrapper);
                if (CollectionUtils.isEmpty(userTeamList) || userTeamList.size() <= 1){
                    throw new BusinessException(ErrorCode.SYSTEM_ERROR);
                }
                //拿到除了队长之后的一条
                UserTeam nextUserTeam = userTeamList.get(1);
                //转移队长权限
                Long nextUserId = nextUserTeam.getUserId();
                //把队伍的 userId字段改为 nextUserId
                Team updateTeam = new Team();
                updateTeam.setId(teamId);
                updateTeam.setUserId(nextUserId);
                boolean result = this.updateById(updateTeam);
                if (!result){
                    throw new BusinessException(ErrorCode.SYSTEM_ERROR, "队伍更新队长失败");
                }
            }
        }
        //      2. 非队长，自己退出队伍，（只剩一人删除关系表信息）
        return userTeamService.remove(queryWrapper);
    }

    /**
     * 删除队伍
     *
     * @param teamDeleteRequest
     * @param loginUser
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteTeam(TeamDeleteRequest teamDeleteRequest, User loginUser) {
        //1. 校验请求参数
        Long teamId = teamDeleteRequest.getTeamId();
        if (teamId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //2. 校验队伍是否存在
        Team team = getTeamByTeamId(teamId);
        //3. 校验解散者是不是队伍的队长并且不是管理员
        if (!team.getUserId().equals(loginUser.getId()) && loginUser.getUserRole() < 1){
            throw new BusinessException(ErrorCode.NO_AUTH, "无访问权限");
        }
        //4. 移除所有加入队伍的关联信息
        QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
        userTeamQueryWrapper.eq("teamId", teamId);
        boolean result = userTeamService.remove(userTeamQueryWrapper);
        if (!result){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR);
        }
        //5. 删除队伍
        return this.removeById(teamId);
    }

    /**
     * 根据队伍id 获取所有加入队伍的用户信息
     *
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<User> listJoinUsers(Long id) {
        if (id == null || id < 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        List<User> userList = baseMapper.selectJoinUsers(id);
        return userList.stream().map(user -> userService.getSafetyUser(user)).collect(Collectors.toList());
    }

    /**
     * 根据队伍id 获取队伍人数
     *
     * @param teamId
     * @return
     */
    private long getTeamNumsByTeamId(long teamId){
        QueryWrapper<UserTeam> wrapper = new QueryWrapper<>();
        wrapper.eq("teamId", teamId);
        return userTeamService.count(wrapper);
    }

    /**
     * 根据队伍id 获取队伍信息
     *
     * @param teamId
     * @return
     */
    private Team getTeamByTeamId(Long teamId){
        if (teamId == null || teamId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        Team team = this.getById(teamId);
        if (team == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "队伍不存在");
        }
        return team;
    }

}




