package com.friend.controller;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.friend.common.BaseResponse;
import com.friend.common.ErrorCode;
import com.friend.common.ResultUtils;
import com.friend.exception.BusinessException;
import com.friend.model.domain.Team;
import com.friend.model.domain.User;
import com.friend.model.domain.UserTeam;
import com.friend.model.domain.request.*;
import com.friend.model.dto.TeamQuery;
import com.friend.model.enums.TeamStatusEnum;
import com.friend.model.vo.TeamUserVO;
import com.friend.service.TeamService;
import com.friend.service.UserService;
import com.friend.service.UserTeamService;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 队伍接口
 *
 * @author Alonso
 */
@RestController
@RequestMapping("/team")
@Slf4j
//@CrossOrigin(origins = {"http://friend.llong7.cn"}, allowCredentials = "true")
//@CrossOrigin(origins = {"http://127.0.0.1:5173"}, allowCredentials = "true")
public class TeamController {

    @Resource
    private TeamService teamService;

    @Resource
    private UserService userService;

    @Resource
    private UserTeamService userTeamService;

    /**
     * 创建队伍
     *
     * @param teamAddRequest
     * @param request
     * @return
     */
    @PostMapping("/add")
    public BaseResponse<Long> addTeam(@RequestBody TeamAddRequest teamAddRequest, HttpServletRequest request){
        //判断
        if (teamAddRequest == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //获取用户登录态
        User loginUser = userService.getCurrentUserLogin(request);
        Team team = new Team();
        //将 teamAddRequest 中的内容拷贝到 team中
        BeanUtils.copyProperties(teamAddRequest, team);
        long teamId = teamService.addTeam(team, loginUser);
        return ResultUtils.success(teamId);
    }

    /**
     * 删除队伍
     *
     * @param teamDeleteRequest
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public BaseResponse<Boolean> deleteTeam(@RequestBody TeamDeleteRequest teamDeleteRequest, HttpServletRequest request){
        Long teamId = teamDeleteRequest.getTeamId();
        if (teamId <= 0){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User loginUser = userService.getCurrentUserLogin(request);
        boolean result = teamService.deleteTeam(teamDeleteRequest, loginUser);
        if (!result){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "队伍删除失败");
        }
        //删除成功直接返回 true
        return ResultUtils.success(true);
    }

    /**
     * 修改队伍
     *
     * @param teamUpdateRequest
     * @return
     */
    @PostMapping("/update")
    public BaseResponse<Boolean> updateTeam(@RequestBody TeamUpdateRequest teamUpdateRequest, HttpServletRequest request){
        if (teamUpdateRequest == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //获取用户登录态
        User loginUser = userService.getCurrentUserLogin(request);
        boolean result = teamService.updateTeam(teamUpdateRequest, loginUser);
        if (!result){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "队伍修改失败");
        }
        return ResultUtils.success(true);
    }

    /**
     * 修改队伍头像
     *
     * @param file
     * @param teamId
     * @return
     */
    @PostMapping("/updateTeamUrl")
    public BaseResponse<Integer> updateTeamUrl(@RequestParam(value = "file") MultipartFile file, Long teamId){
        //校验参数是否为空
        if (teamId == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //触发更新
        int result = teamService.updateTeamUrl(file, teamId);
        return ResultUtils.success(result);
    }

    /**
     * 根据 id 查询队伍
     *
     * @param id
     * @return
     */
    @GetMapping("/get")
    public BaseResponse<TeamUserVO> getTeamById(long id){
        if (id <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //根据队伍Id，查team
        TeamQuery teamQuery = new TeamQuery();
        teamQuery.setId(id);
        List<TeamUserVO> teamList = teamService.listTeams(teamQuery, true);
        if (CollectionUtils.isEmpty(teamList)) {
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //防止查到多个队伍，直接拿到首个
        TeamUserVO team = teamList.get(0);
        if (team == null) {
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        //根据队伍Id，查询user_team表，获取加入的用户
        List<User> joinUser = teamService.listJoinUsers(team.getId());
        team.setJoinUsers(joinUser);
        return ResultUtils.success(team);
    }

    /**
     * 查询所有队伍
     *
     * @param teamQuery 请求参数包装类
     * @return
     */
    @GetMapping("/list")
    public BaseResponse<List<TeamUserVO>> listTeams(TeamQuery teamQuery, HttpServletRequest request) {
        if (teamQuery == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        boolean isAdmin = userService.isAdmin(request);
        // 1.查询队伍列表
        List<TeamUserVO> teamList = teamService.listTeams(teamQuery, isAdmin);
        final List<Long> teamIdList = teamList.stream().map(TeamUserVO::getId).collect(Collectors.toList());
        // 2.判断当前用户是否已加入队伍
        QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
        try {
            User loginUser = userService.getCurrentUserLogin(request);
            userTeamQueryWrapper.eq("userId", loginUser.getId());
            userTeamQueryWrapper.in("teamId", teamIdList);
            List<UserTeam> userTeamList = userTeamService.list(userTeamQueryWrapper);
            // 已加入的队伍 id 集合
            Set<Long> hasJoinTeamIdSet = userTeamList.stream().map(UserTeam::getTeamId).collect(Collectors.toSet());
            teamList.forEach(team -> {
                boolean hasJoin = hasJoinTeamIdSet.contains(team.getId());
                team.setHasJoin(hasJoin);
            });
        } catch (Exception e) {}
        //3.查询已加入队伍的人数
        QueryWrapper<UserTeam> userTeamJoinQueryWrapper = new QueryWrapper<>();
        userTeamJoinQueryWrapper.in("teamId", teamIdList);
        List<UserTeam> userTeamList = userTeamService.list(userTeamJoinQueryWrapper);
        //队伍 id => 加入这个队伍的用户列表
        Map<Long, List<UserTeam>> teamIdUserTeamList = userTeamList.stream().collect(Collectors.groupingBy(UserTeam::getTeamId));
        //getOrDefault(key, default)如果存在key, 则返回其对应的value, 否则返回给定的默认值
        teamList.forEach(team -> team.setHasJoinNum(teamIdUserTeamList.getOrDefault(team.getId(), new ArrayList<>()).size()));
        return ResultUtils.success(teamList);
    }

    /**
     * 查询我创建的队伍
     *
     * @param teamQuery
     * @param request
     * @return
     */
    @GetMapping("/list/my/create")
    public BaseResponse<List<TeamUserVO>> listMyCreateTeams(TeamQuery teamQuery, HttpServletRequest request){
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User loginUser = userService.getCurrentUserLogin(request);
        //将自己的 userId 放入查询封装类中
        teamQuery.setUserId(loginUser.getId());
        //因为是查询自己创建的队伍，所以只要是登录了的，就有权限查
        List<TeamUserVO> listTeams = teamService.listMyCreateTeams(teamQuery, true);
        return ResultUtils.success(listTeams);
    }

    /**
     * 查询我加入的队伍
     *
     * @param teamQuery
     * @param request
     * @return
     */
    @GetMapping("/list/my/join")
    public BaseResponse<List<TeamUserVO>> listMyJoinTeams(TeamQuery teamQuery, HttpServletRequest request){
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User loginUser = userService.getCurrentUserLogin(request);
        Long userId = loginUser.getId();
        QueryWrapper<UserTeam> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("userId", userId);
        //userTeamList 自己加入的所有队伍信息
        List<UserTeam> userTeamList = userTeamService.list(queryWrapper);
        //取出不重复的队伍 id
        //正常情况下一个用户只能加入一次队伍，所以不会有重复的队伍 id
        //但是严谨点，如果有脏数据，或者是后台被修改成一个用户加入一个队伍好几次
        //，就会出现重复的队伍
        Map<Long, List<UserTeam>> listMap = userTeamList.stream()
                .collect(Collectors.groupingBy(UserTeam::getTeamId));
        List<Long> idList = new ArrayList<>(listMap.keySet());
        teamQuery.setIdList(idList);
        teamQuery.setUserId(userId);
        List<TeamUserVO> listTeams = teamService.listMyJoinTeams(teamQuery, true);
        return ResultUtils.success(listTeams);
    }

    /**
     * 查询私有队伍（管理员权限）
     *
     * @param teamQuery
     * @param request
     * @return
     */
    @GetMapping("/list/privateTeam")
    public BaseResponse<List<TeamUserVO>> listPrivateTeams(TeamQuery teamQuery, HttpServletRequest request){
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        List<TeamUserVO> teamUserVOList = teamService.listPrivateTeams(teamQuery, true);
        return ResultUtils.success(teamUserVOList);
    }

    /**
     * 查询所有队伍（分页）
     *
     * @param teamQuery
     * @return
     */
    @GetMapping("/list/page")
    public BaseResponse<Page<Team>> listTeamsByPage(TeamQuery teamQuery, HttpServletRequest request){
        if (teamQuery == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        //拿到自己的id
        User loginUser = userService.getCurrentUserLogin(request);
        Long userId = loginUser.getId();
        Team team = new Team();
        BeanUtils.copyProperties(teamQuery, team);
        //获取分页信息
        Page<Team> page = new Page<>(teamQuery.getPageNum(), teamQuery.getPageSize());
        QueryWrapper<Team> queryWrapper = new QueryWrapper<>(team);
        Integer status = teamQuery.getStatus();
        //获取队伍当前状态
        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
        //默认查询队伍的状态为公开
        if (statusEnum == null){
            statusEnum = TeamStatusEnum.PUBLIC;
        }
        queryWrapper.eq("status", statusEnum.getValue());
        String searchText = teamQuery.getSearchText();
        if (StringUtils.isNotBlank(searchText)){
            queryWrapper.and(qw -> qw.like("name", searchText)
                    .or().like("description", searchText));
        }
        Page<Team> teamListByPage = teamService.page(page, queryWrapper);
        List<Team> records = teamListByPage.getRecords();
        for (Team teamPage : records) {
            //队伍id
            Long teamId = teamPage.getId();
            QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamId);
            //已加入队伍人数
            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);
            //放入 team的 hasJoinNum 字段
            teamPage.setHasJoinNum((int)hasJoinNum);
            userTeamQueryWrapper = new QueryWrapper<>();
            userTeamQueryWrapper.eq("teamId", teamPage.getId());
            userTeamQueryWrapper.eq("userId", userId);
            List<UserTeam> list = userTeamService.list(userTeamQueryWrapper);
            if (list.size() != 0){
                teamPage.setHasJoin(true);
            }
        }
        return ResultUtils.success(teamListByPage);
    }

//    public BaseResponse<Page<Team>> listTeamsByPage(TeamQuery teamQuery){
//        if (teamQuery == null){
//            throw new BusinessException(ErrorCode.PARAMS_ERROR);
//        }
//        Team team = new Team();
//        BeanUtils.copyProperties(teamQuery, team);
//        //获取分页信息
//        Page<Team> page = new Page<>(teamQuery.getPageNum(), teamQuery.getPageSize());
//        QueryWrapper<Team> queryWrapper = new QueryWrapper<>(team);
//        Integer status = teamQuery.getStatus();
//        //获取队伍当前状态
//        TeamStatusEnum statusEnum = TeamStatusEnum.getEnumByValue(status);
//        //默认查询队伍的状态为公开
//        if (statusEnum == null){
//            statusEnum = TeamStatusEnum.PUBLIC;
//        }
//        queryWrapper.eq("status", statusEnum.getValue());
//        String searchText = teamQuery.getSearchText();
//        if (StringUtils.isNotBlank(searchText)){
//            queryWrapper.and(qw -> qw.like("name", searchText)
//                    .or().like("description", searchText));
//        }
//        Page<Team> teamListByPage = teamService.page(page, queryWrapper);
//        List<Team> records = teamListByPage.getRecords();
//        for (Team teamPage : records) {
//            //队伍id
//            Long teamId = teamPage.getId();
//            QueryWrapper<UserTeam> userTeamQueryWrapper = new QueryWrapper<>();
//            userTeamQueryWrapper.eq("teamId", teamId);
//            //已加入队伍人数
//            long hasJoinNum = userTeamService.count(userTeamQueryWrapper);
//            //放入 team的 hasJoinNum 字段
//            teamPage.setHasJoinNum((int)hasJoinNum);
//        }
//        return ResultUtils.success(teamListByPage);
//    }

    /**
     * 加入队伍
     *
     * @param teamJoinRequest
     * @param request
     * @return
     */
    @PostMapping("/join")
    public BaseResponse<Boolean> joinTeam(@RequestBody TeamJoinRequest teamJoinRequest, HttpServletRequest request){
        if (teamJoinRequest == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        User loginUser = userService.getCurrentUserLogin(request);
        boolean result = teamService.joinTeam(teamJoinRequest, loginUser);
        if (!result){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "加入队伍失败");
        }
        return ResultUtils.success(true);
    }

    /**
     * 退出队伍
     *
     * @param teamQuitRequest
     * @param request
     * @return
     */
    @PostMapping("/quit")
    public BaseResponse<Boolean> quitTeam(@RequestBody TeamQuitRequest teamQuitRequest, HttpServletRequest request){
        if (teamQuitRequest == null){
            throw new BusinessException(ErrorCode.NULL_ERROR);
        }
        User loginUser = userService.getCurrentUserLogin(request);
        boolean result = teamService.quitTeam(teamQuitRequest, loginUser);
        if (!result){
            throw new BusinessException(ErrorCode.SYSTEM_ERROR, "加入队伍失败");
        }
        return ResultUtils.success(true);
    }
}
