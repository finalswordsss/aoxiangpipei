package com.friend.job;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.friend.model.domain.User;
import com.friend.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 定时任务（预热缓存）
 * @author Alonso
 */
@Component
@Slf4j
public class PreCacheJob {

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private UserService userService;

    @Resource
    private RedisTemplate<String,Object> redisTemplate;

    //系统的标识
    public static final String PRODUCT_NAME = "friend";

    //重点用户
    private List<Long> mainUserList = Arrays.asList(1L);

    //每天准点执行，预热主页推荐用户
    //每天 14:29分 执行定时任务（预热缓存）
    @Scheduled(cron = "0 08 22 * * *")
    public void doCacheReCommendUser(){
        //getLock：获取分布式锁特性，key的命名逻辑和设置缓存的一样
        //两个地方都用到了系统的标识（friend），所以可以把他提取出来
        RLock lock = redissonClient.getLock(PRODUCT_NAME + ":precachejob:docache:lock");
        try {
            //只有一个线程能获取到锁
            //0：等待时间（每天只能允许一个线程执行定时任务，不存在没抢到锁就等待的情况，没抢到就放弃）
            //30000L：过期时间（锁释放时间）
            if (lock.tryLock(0, 30000L, TimeUnit.MILLISECONDS)){
                System.out.println("getLock: "+Thread.currentThread().getId());
                for (Long userId : mainUserList) {
                    QueryWrapper<User> queryWrapper = new QueryWrapper<>();
                    //预热 1页20条数据
                    Page<User> userPage = userService.page(new Page<>(1, 20), queryWrapper);
                    String redisKey = String.format(PRODUCT_NAME + ":user:recommend:%s", userId);
                    ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
                    try {
                        //写缓存
                        valueOperations.set(redisKey, userPage, 30000, TimeUnit.MILLISECONDS);
                    } catch (Exception e) {
                        log.error("redis set key error",e);
                    }
                }
            }
        } catch (InterruptedException e) {
            log.error("doCacheReCommendUser error", e);
        }finally {
            //注意释放锁要写在 finally 中（写在 try 中，如果前面发生异常就不会执行释放锁）
            //只能释放自己的锁
            if (lock.isHeldByCurrentThread()){
                 System.out.println("unlock:" + Thread.currentThread().getId());
                 lock.unlock();
            }
        }
    }
}
