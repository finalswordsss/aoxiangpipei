package com.friend.once;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class TableUserInfo {

    @ExcelProperty("成员编号")
    private String planetCode;

    @ExcelProperty("昵称")
    private String userName;
}
