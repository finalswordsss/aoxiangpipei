package com.friend.once;

import com.alibaba.excel.EasyExcel;

import java.util.List;

public class ImportExcel {
    public static void main(String[] args) {
        String fileName = "E:\\yupiCode\\user-center-backend\\src\\main\\resources\\ExcelByListener.xlsx";

        //监听器读取
        //listenerRead(fileName);

        //同步读取
        synchronousRead(fileName);
    }

    public static void listenerRead(String fileName){
        EasyExcel.read(fileName, TableUserInfo.class, new TableUserInfoListener()).sheet().doRead();
    }

    public static void synchronousRead(String fileName){
        List<TableUserInfo> list = EasyExcel.read(fileName).head(TableUserInfo.class).sheet().doReadSync();
        for (TableUserInfo data : list) {
            System.out.println(data);
        }
    }
}
