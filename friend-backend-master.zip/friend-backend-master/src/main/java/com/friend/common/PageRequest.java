package com.friend.common;

import lombok.Data;

import java.io.Serializable;

/**
 * 通用的分页请求参数（请求类）
 *
 * @author Alonso
 */
@Data
public class PageRequest implements Serializable {


    private static final long serialVersionUID = -254141710247445487L;

    /**
     * 当前页码
     */
    protected int pageNum;

    /**
     * 当前页显示条数
     */
    protected int pageSize;
}
