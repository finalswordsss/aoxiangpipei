package com.friend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.friend.model.domain.UserTeam;

/**
* @author Alonso
* @description 针对表【user_team(用户队伍关系表)】的数据库操作Mapper
* @createDate 2023-02-02 14:05:17
* @Entity com.friend.model.domain.UserTeam
*/
public interface UserTeamMapper extends BaseMapper<UserTeam> {

}




