package com.friend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.friend.model.domain.User;


/**
 * @Entity com.friend.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




