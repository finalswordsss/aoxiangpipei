package com.friend.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.friend.model.domain.Team;
import com.friend.model.domain.User;

import java.util.List;

/**
* @author Alonso
* @description 针对表【team(队伍表)】的数据库操作Mapper
* @createDate 2023-02-02 14:02:57
* @Entity com.friend.model.domain.Team
*/
public interface TeamMapper extends BaseMapper<Team> {
    /**
     * 根据队伍id 查询加入队伍的用户信息列表
     *
     * @param id
     * @return
     */
    List<User> selectJoinUsers(Long id);
}




