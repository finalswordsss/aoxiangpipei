-- auto-generated definition
create table user
(
    username     varchar(256) charset utf8          null comment '用户昵称',
    id           bigint auto_increment comment 'id'
        primary key,
    userAccount  varchar(256) charset utf8          null comment '账号',
    profile      varchar(512) charset utf8          null comment '个人简介',
    avatarUrl    varchar(1024) charset utf8         null comment '用户头像',
    gender       int                                null comment '性别 0-男 1- 女',
    userPassword varchar(512) charset utf8          not null comment '密码',
    phone        varchar(128) charset utf8          null comment '电话',
    email        varchar(512) charset utf8          null comment '邮箱',
    userStatus   int      default 0                 not null comment '状态 0 - 正常',
    createTime   datetime default CURRENT_TIMESTAMP null comment '创建时间',
    updateTime   datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete     tinyint  default 0                 not null comment '是否删除',
    userRole     int      default 0                 not null comment '用户角色 0 - 普通用户 1 - 管理员',
    tags         varchar(1024) charset utf8         null comment '标签列表',
    planetCode   varchar(512)                       null comment '编号'
)
    comment '用户表';

alter table user add column tags varchar(1024) null comment '标签列表';


-- auto-generated definition
create table tag
(
    id         bigint auto_increment comment 'id'
        primary key,
    tagName    varchar(256)                       null comment '标签名称',
    userId     bigint                             null comment '用户 id',
    parentId   bigint                             null comment '父标签 id',
    isParent   tinyint                            null comment '0 - 不是，1 - 父标签',
    createTime datetime default CURRENT_TIMESTAMP null comment '创建时间',
    updateTime datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete   tinyint  default 0                 not null comment '是否删除',
    constraint idx_userId
        unique (userId),
    constraint unildx_tagName
        unique (tagName)
)
    comment '标签表' charset = utf8;

create table team
(
    id          bigint auto_increment comment 'id'
        primary key,
    name        varchar(256)                        not null comment '队伍名称',
    description varchar(1024)                       null comment '队伍描述',
    maxNum      int       default 1                 not null comment '最大人数',
    expireTime  timestamp                           null comment '过期时间',
    userId      bigint                              null comment '创建人 id',
    status      int       default 0                 not null comment ' 0 - 公开，1 - 私有，2 - 加密',
    password    varchar(512)                        null comment '密码',
    createTime  timestamp default CURRENT_TIMESTAMP null comment '创建时间',
    updateTime  datetime  default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete    tinyint   default 0                 not null comment '是否删除',
    teamUrl     varchar(1024)                       null comment '队伍头像',
    hasJoinNum  int                                 null comment '已加入队伍人数',
    hasJoin     tinyint(1)                          null comment '是否已加入队伍'
)
    comment '队伍表' charset = utf8;




-- auto-generated definition
create table user_team
(
    id         bigint auto_increment comment 'id'
        primary key,
    userId     bigint                             null comment '用户 id',
    teamId     bigint                             null comment '队伍 id',
    joinTime   datetime                           null comment '加入时间',
    createTime datetime default CURRENT_TIMESTAMP null comment '创建时间',
    updateTime datetime default CURRENT_TIMESTAMP null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete   tinyint  default 0                 not null comment '是否删除'
)
    comment '用户队伍关系表' charset = utf8;